# Write a program to print numbers from 1 to 10 using a for loop.
print("**Print Number Using a Loop")

for i in range(1,11):
    print(i)