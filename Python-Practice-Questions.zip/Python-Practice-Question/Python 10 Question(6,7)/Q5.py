# Write a program to input a string and use a for loop to print each character on a new line.

print("** Print Characters of a String **")
words = str(input("Enter a character : "))
for word in words :
    # print(count)
    print(word)



