# Write a program that takes a string as input and uses the len function to count and print the number of characters in the string.

print("** COunt Characters in a String **")
words = str(input("Enter charactiers : "))
print(len(words))
