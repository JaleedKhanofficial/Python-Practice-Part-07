# Write a program that takes a string as input and uses slicing to reverse the string. Print the reversed string.

print("** Reverse a String **")
words = str(input("Enter charactiers : "))
word = words[ ::-1]
print(word)
