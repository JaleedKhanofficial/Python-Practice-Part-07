# Write a user-defined function greet(name) that takes a name as an argument and prints a greeting message like "Hello, [name]! Welcome to Python."


def greet(name):
    print("Hello, " + name + "! Welcome to Python.")

greet("Jaleed khan")
