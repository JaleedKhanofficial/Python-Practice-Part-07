# Write a program that takes two numbers as input and outputs their sum, difference, product, and quotient.

print("**Simple Arithmetic**")
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

# sum of two number.
sum = num1+num2
print("The sum of the two number is :",sum)

# difference.
diff = num1 - num2
print("The difference of numbers (second from first) :",diff)

# product
product = num1 * num2
print("The product of the two number is :",product)

# quotient
quot = num1/num2
print("The quotient is :",quot)