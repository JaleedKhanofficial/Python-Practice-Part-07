# Write a program to define a dictionary with at least 5 key-value pairs and print all the values using a loop.

print("** Print All Values **")

# Define the dictionary
my_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Print all the values
print("Values in the dictionary:")
for value in my_dict.values():
    print(value)

# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial