# Write a program to define a dictionary with at least 5 key-value pairs and print all the keys using a loop.

print("** Print All Keys **")

# Define the dictionary
my_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Print all the keys
print("Keys in the dictionary:")
for key in my_dict:
    print(key)


# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial