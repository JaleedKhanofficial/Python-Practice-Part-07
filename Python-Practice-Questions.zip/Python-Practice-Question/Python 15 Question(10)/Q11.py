# Write a program to calculate and print the number of key-value pairs in a dictionary.

print("** Find the Length of a Dictionary **")

# Define the dictionary
my_dict = {'name': 'Alice', 'age': 25, 'city': 'New York'}

# Calculate and print the number of key-value pairs
print("The number of key-value pairs is:", len(my_dict))

# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial