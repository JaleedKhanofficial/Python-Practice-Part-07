# Write a program to find and print the number of elements in a tuple using the len() function.

print("** Find the Length of a Tuple **")

# Define a tuple
my_tuple = ('apple', 'banana', 'cherry', 'dates')

# Find the length of the tuple
length = len(my_tuple)

# Print the result
print("The number of elements in the tuple:", length)


# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial