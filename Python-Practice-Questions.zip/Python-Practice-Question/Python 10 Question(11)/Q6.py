# Write a program to create a tuple and print a slice of the tuple (e.g., from index 2 to 4).

print("** Slice a Tuple **")

# Define a tuple
my_tuple = (10, 20, 30, 40, 50, 60)

# Slice the tuple (from index 2 to 4)
sliced_tuple = my_tuple[2:5]

# Print the sliced tuple
print("Sliced tuple (index 2 to 4):", sliced_tuple)


# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial