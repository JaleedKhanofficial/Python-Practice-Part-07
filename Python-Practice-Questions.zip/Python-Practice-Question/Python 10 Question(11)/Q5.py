# Write a program to repeat the elements of a tuple 3 times using the * operator and print the resulting tuple.

print("** Repeat a Tuple **")

# Define a tuple
my_tuple = ('A', 'B', 'C')

# Repeat the tuple 3 times
repeated_tuple = my_tuple * 3

# Print the result
print("Repeated tuple:", repeated_tuple)


# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial