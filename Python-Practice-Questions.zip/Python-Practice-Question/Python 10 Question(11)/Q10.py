# Write a program that takes a list as input from the user, converts it into a tuple, and prints the resulting tuple.

print("** Convert a List into a Tuple **")

# Input a list from the user
user_input = input("Enter elements of the list separated by spaces: ").split()

# Convert the list to a tuple
my_tuple = tuple(user_input)

# Print the resulting tuple
print("The tuple is:", my_tuple)

# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial