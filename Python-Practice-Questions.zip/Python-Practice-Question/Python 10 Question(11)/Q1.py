# Write a program to create a tuple with at least 5 elements and print the tuple.

print("** Create and Print a Tuple **")

# Create a tuple with 5 elements
my_tuple = (10, 20, 30, 40, 50)

# Print the tuple
print("The tuple is:", my_tuple)

# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial