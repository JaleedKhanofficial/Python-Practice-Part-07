# Write a program to create two tuples, concatenate them using the + operator, and print the result.

print("** Concatenate Two Tuples **")

# Define two tuples
tuple1 = (1, 2, 3)
tuple2 = (4, 5, 6)

# Concatenate the tuples
concatenated_tuple = tuple1 + tuple2

# Print the result
print("Concatenated tuple:", concatenated_tuple)


# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial