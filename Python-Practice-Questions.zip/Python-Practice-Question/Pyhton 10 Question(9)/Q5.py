# Create two lists of your favorite fruits and vegetables. Concatenate these lists and print the combined list.print("** Combine Fruits and Vegetables **")

# Lists of fruits and vegetables
fruits = ['apple', 'banana', 'grapes', 'watermelon']
vegetables = ['potato', 'carrot', 'corn', 'eggplant']

# Combine the two lists
favorites = fruits + vegetables

# Display the combined list
print("My favorite fruits and vegetables are:", favorites)



# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial