# Write a program that builds a list of the squares of numbers from 1 to 10 using a loop.

print("** Square of Numbers **")

# Generate a list of squares for numbers from 0 to 10
squares = [x**2 for x in range(11)]

# Print the list of squares
print("Squares of numbers from 0 to 10:", squares)



# GitHub : jaleedkhanofficial
# linkedin.com/in/jaleedkhanofficial